zapatos = "Precio de los zapatos: "
pre_zapatos =350000

tenis = "Precio de los tenis: "
pre_tenis = 280000

camisetas = "precio de las camisetas: "
pre_camisetas = 175000

jeans = "Precio de los jeans: "
pre_jeans = 200000


print(zapatos, pre_zapatos)
print(tenis, pre_tenis)
print(camisetas, pre_camisetas)
print(jeans, pre_jeans)

SUMA = "Costo total de los articulos: "
sumar = pre_zapatos + pre_tenis + pre_camisetas + pre_jeans
print(SUMA, sumar)

promedio_total = "El promedio total es: "
promedio = (sumar)/4
print(promedio_total, promedio)


porcentaje = "Nuevo precio del jeans: "
sub_porcentaje = pre_jeans * 0.062
pre_jeans = pre_jeans + sub_porcentaje
print(porcentaje, pre_jeans)


porcent= "Nuev precio total zapatos: "
sub_porcent = pre_zapatos - (pre_zapatos * 0.008)
print(porcent, sub_porcent)


