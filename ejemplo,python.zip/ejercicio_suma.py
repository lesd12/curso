number_one = 6
number_two = 3

#This is a coment of one line 
#operacion de sumar los dos numeros 

"""
This is a multi_line coment
sumar = number_one + number_two

print(sumar)

"""

resta = number_one - number_two
print(resta)
