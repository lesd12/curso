saldo_cuenta= 200000
print(saldo_cuenta)