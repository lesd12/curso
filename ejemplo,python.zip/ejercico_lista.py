#example of list
#nombres = ["jesus", "maria", "jose"]
#print(nombres[1])

#diccionario
#datos_persona = ["jesus", 33 , 1.75 ,True] en forma de lista
#en forma de diccionario
"""
datos_persona = {
    "nombre" : "jesus",
    "edad" : 33,
    "estatura" : 1.75,
    "soltero?" : True
    
}
"""

#en forma de tabala
datos_persona = ("jesus", 33,1.75,True)
print(datos_persona[2])
